﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Net;
using System.IO;
using System.Windows.Navigation;
using System.Text.RegularExpressions;
using System.Diagnostics;

using static System.Net.WebRequestMethods;

namespace Prova_summon_altra_finestra
{
    /// <summary>
    /// Logica di interazione per Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }
        private void ButtonClicked(object sender, RoutedEventArgs e)
        {
            var wk = myTextBox.Text;


            try
            {
                
                using (StreamReader sr = new StreamReader("Key.txt"))
                {
                    
                    string primaRiga = sr.ReadLine();

                    if (wk == primaRiga)
                    {
                        MessageBox.Show("Licenza corretta e convalidata!");
                    }
                    else
                    {
                        MessageBox.Show("Licenza non valida");
                    }

                }
            }
            catch (Exception ex)
            {
                
                MessageBox.Show("Errore: " + ex.Message);
            }


            string Dk = System.IO.File.ReadAllText("Key.txt");

           
        }
    }
}
