﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.Drawing;

namespace Prova_summon_altra_finestra
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            string fileName = "Time.txt"; // Nome del file da cercare
            if (System.IO.File.Exists(fileName)) // Verifica se il file esiste
            {
                CheckDate();
            }
            else
            {
                FirstRun();
            }
            InitializeComponent();
        }

        private void ButtonClicked(object sender, RoutedEventArgs e)
        {
            Window1 Window1 = new Window1();
            Window1.Show();
            using (WebClient client = new WebClient())
            {
                string url = "https://raw.githubusercontent.com/ilpiruz/LicenseKey/main/Key.txt";
                string fileName = "Key.txt";
                client.DownloadFile(url, fileName);
                Console.WriteLine("File scaricato con successo!");
            }
        }

        
        private void FirstRun()
        {
            DateTime now = DateTime.Now;
       
            string dateString = now.ToString("mm");

            System.IO.File.WriteAllText("Time.txt", dateString);
        }
        private void CheckDate()
        {
            DateTime now = DateTime.Now;

          
            string Today = now.ToString("mm");


            string ad = System.IO.File.ReadAllText("Time.txt");

            if (Today == ad)
            {
                
            }
            else
            {
                int Readed = int.Parse(Today);
                Readed -= 7;
                Today = Readed.ToString();

                if (Today == ad)
                {
                    MessageBox.Show("Trial Expired");
                    Environment.Exit(0);

                }
            }

           

        }

        
    }
}
